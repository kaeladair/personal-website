﻿=== Dove Cursor Set ===

By: The Sword of the Heart (http://www.rw-designer.com/user/1674)

Download: http://www.rw-designer.com/cursor-set/dove

Author's decription:

I started with the dove cursor from the Christianity section of CursorMania, then modified and animated until I got a whole set. Enjoy. ;)

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.